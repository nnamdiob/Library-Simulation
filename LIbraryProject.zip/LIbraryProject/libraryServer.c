#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>
#include <signal.h>
#include <semaphore.h>

#include "library.h" 

// External Functions
extern void *runTimer(void *);
extern void *runQueueCoordination(void *); 
extern void *runDisplay(void *);
extern void startAcceptingPatrons(Library *); 

// These are the available books
const char *BookTitles[NUM_BOOK_ITEMS] = {
    "To Kill a Mockingbird",
    "1984",
    "Pride and Prejudice",
    "The Great Gatsby",
    "Moby Dick",
    "War and Peace",
    "The Catcher in the Rye",
    "The Hobbit",
    "Fahrenheit 451",
    "Jane Eyre",
    "The Lord of the Rings"
};

// These are the rental fees for the books
const float BookRentalFees[NUM_BOOK_ITEMS] = {2.99, 3.99, 5.29, 6.99, 1.99, 4.19, 3.99, 7.99, 2.29, 3.79, 5.99};

// These are the preparation times for the books (e.g., finding/preparing them for pickup)
const float BookPrepTime[NUM_BOOK_ITEMS] = {10, 12, 10, 8, 8, 10, 2, 2, 2, 2, 3};
const float BookFillTime[NUM_BOOK_ITEMS] = {5, 5, 5, 5, 5, 5, 5, 5, 10, 15, 20}; // Time to gather books

// This is where it all begins
int main()
{
  Library bookRentalLibrary;

  pthread_t timerThread, queueCoordinatorThread, drawingThread;

  if (sem_init(&bookRentalLibrary.QueueSemaphore, 0, 1) < 0)
  {
    printf("Error: on semaphore init.\n");
    exit(1);
  }

  // Initialize the patronQueue to have no patrons
  for (int i = 0; i < MAX_PATRONS; i++)
  {
    bookRentalLibrary.patronQueue[i].patronPid = 0;
    bookRentalLibrary.patronQueue[i].startedRental = 0;
    bookRentalLibrary.patronQueue[i].rental.rentalNumber = NO_RENTAL_YET;
    bookRentalLibrary.nextRentalNumber = 0;
  }

  // Spawn a thread to start the timer (for book preparation times)
  pthread_create(&timerThread, NULL, runTimer, (void *)&bookRentalLibrary);

  // Spawn a thread to handle coordination of the patron queue
  pthread_create(&queueCoordinatorThread, NULL, runQueueCoordination, (void *)&bookRentalLibrary);

  // Spawn a thread to handle display
  pthread_create(&drawingThread, NULL, runDisplay, (void *)&bookRentalLibrary);

  // Start handling patrons (keep doing until a SHUT_DOWN)
  startAcceptingPatrons(&bookRentalLibrary);

  printf("Library Closed\n");
}
