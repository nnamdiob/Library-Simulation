

#include <unistd.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <X11/Xlib.h>
#include <pthread.h>
#include <semaphore.h>

#include "library.h"
#include "display.h"

#define PATRON_WIDTH 100
#define PATRON_HEIGHT 45
#define PATRON_GAP 5

#define ENV_WIDTH 1055
#define ENV_HEIGHT 200

const unsigned int TEXT_COLOR = 0x000000;
const unsigned int WAIT_TO_RENT_COLOR = 0x800080;
const unsigned int RENTING_COLOR = 0x99DD99;
const unsigned int WAIT_TO_PICKUP_COLOR = 0xEEAAAA;
const unsigned int PICKING_UP_COLOR = 0xCCCCEE;

const unsigned int BORDER_COLOR = 0x000000;
const unsigned int BLANK_COLOR = 0xFFFFFF;
const unsigned int RENTAL_WINDOW_COLOR = 0xFFFF00;
const unsigned int PICKUP_WINDOW_COLOR = 0x00FFFF;
const unsigned int ROOF_COLOR = 0x770000;
const unsigned int LIBRARY_COLOR = 0xEEEEDD;

// Display-related variables
Display *display;
Window win;
GC gc;

// Structure for tracking patrons being drawn
typedef struct patron
{
    unsigned int patronPid;
    unsigned char rentalNumber;
    unsigned char queueIndex;
    short destX;
    short currX;
    short currY;
    float speed;
    unsigned int color;
    Rental rental; // Add rental info for displaying book titles
} PatronGraphic;

// Patrons to draw
PatronGraphic patrons[MAX_PATRONS + 2];
unsigned char numPatrons = 0;

// This will hold the rental ... assuming a maximum of 10 books rented
char rentalString[MAX_BOOK_TITLE_SIZE * 10 + 20];
Rental lastRental;

// A previous copy of the library patron queue
Patron previousPatronQueue[MAX_PATRONS];

// Draw the background
void drawBackground()
{
    // Clear the window
    XSetForeground(display, gc, BLANK_COLOR);
    XFillRectangle(display, win, gc, 0, 0, ENV_WIDTH, ENV_HEIGHT);

    // Draw the library building
    XSetForeground(display, gc, LIBRARY_COLOR);
    XFillRectangle(display, win, gc, 5, 30, ENV_WIDTH - 10, ENV_HEIGHT - 31);
    XSetForeground(display, gc, 0x000000);
    XDrawRectangle(display, win, gc, 5, 30, ENV_WIDTH - 10, ENV_HEIGHT - 31);

    // Draw the rental window
    XSetForeground(display, gc, RENTAL_WINDOW_COLOR);
    XFillRectangle(display, win, gc, 440, 130, 50, 40);
    XSetForeground(display, gc, 0x000000);
    XDrawRectangle(display, win, gc, 440, 130, 50, 40);
    XSetForeground(display, gc, TEXT_COLOR);
    XDrawString(display, win, gc, 450, 128, "RENTAL", 6);

    // Draw the pickup window
    XSetForeground(display, gc, PICKUP_WINDOW_COLOR);
    XFillRectangle(display, win, gc, 965, 130, 50, 40);
    XSetForeground(display, gc, 0x000000);
    XDrawRectangle(display, win, gc, 965, 130, 50, 40);
    XSetForeground(display, gc, TEXT_COLOR);
    XDrawString(display, win, gc, 972, 128, "PICKUP", 6);
}

// Display the books rented by the patron who placed the last rental
void drawRental(Library *library)
{
    if (library->patronQueue[MAX_PATRONS - 1].rental.rentalNumber != NO_RENTAL_YET)
        lastRental = library->patronQueue[MAX_PATRONS - 1].rental;

    if (lastRental.rentalNumber == 0)
        return;

    snprintf(rentalString, sizeof(rentalString), "Last Rental #%d = ", lastRental.rentalNumber);

    for (int i = 0; i < lastRental.numBooks; i++)
    {
        snprintf(rentalString + strlen(rentalString), sizeof(rentalString) - strlen(rentalString) - 1, "%s", lastRental.books[i].title);
        if (i != lastRental.numBooks - 1)
        {
            strncat(rentalString, ", ", sizeof(rentalString) - strlen(rentalString) - 1);
        }
    }

    // Output the rental string
    XSetForeground(display, gc, TEXT_COLOR);
    XDrawString(display, win, gc, 50, 50, rentalString, strlen(rentalString));
}



void drawPatron(int x, int y, int fillColor, unsigned short rentalNumber, Rental rental)
{
    XSetForeground(display, gc, fillColor);
    XFillRectangle(display, win, gc, x, y - 30, PATRON_WIDTH, PATRON_HEIGHT);  // Draw the body of the patron

    // Draw the rental number (as an ID tag on the patron)
    if (rentalNumber != NO_RENTAL_YET)
    {
        XSetForeground(display, gc, TEXT_COLOR);
        char rentalDisplay[11];  // Array to hold the rental number string
        snprintf(rentalDisplay, sizeof(rentalDisplay), "%03d", rentalNumber);
        XDrawString(display, win, gc, x + 42, y - 15, rentalDisplay, strlen(rentalDisplay));
    }

    // Draw the book titles next to the patron
    if (rentalNumber != NO_RENTAL_YET && rental.numBooks > 0)
    {
        XSetForeground(display, gc, TEXT_COLOR);
        char bookDisplay[MAX_BOOK_TITLE_SIZE * 10];
        bookDisplay[0] = '\0'; // Initialize the string to be empty

        snprintf(bookDisplay, sizeof(bookDisplay), "Books: ");
        for (int i = 0; i < rental.numBooks; i++)
        {
            size_t remaining = sizeof(bookDisplay) - strlen(bookDisplay) - 1; // Calculate remaining buffer space

            // Append the title of the book, ensuring no overflow
            strncat(bookDisplay, rental.books[i].title, remaining);

            // Calculate remaining buffer space again and append ", " if there's space
            remaining = sizeof(bookDisplay) - strlen(bookDisplay) - 1;
            if (i != rental.numBooks - 1 && remaining > 2)
                strncat(bookDisplay, ", ", remaining);
        }

        XDrawString(display, win, gc, x + 110, y - 15, bookDisplay, strlen(bookDisplay));
    }
}


// Initialize and open the simulator window with size ENV_WIDTH x ENV_HEIGHT
void initializeWindow()
{
    // Open connection to X server
    display = XOpenDisplay(NULL);

    // Create a simple window, set the title and get the graphics context then
    // make it visible and get ready to draw
    win = XCreateSimpleWindow(display, RootWindow(display, 0), 0, 0, ENV_WIDTH, ENV_HEIGHT, 0, 0x000000, 0xFFFFFF);
    XStoreName(display, win, "Library Queue Simulator");
    gc = XCreateGC(display, win, 0, NULL);
    XMapWindow(display, win);
    XFlush(display);
    usleep(20000); // sleep for 20 milliseconds
}

// Close the display window
void closeWindow()
{
    XFreeGC(display, gc);
    XUnmapWindow(display, win);
    XDestroyWindow(display, win);
    XCloseDisplay(display);
}

// Decide how the patron locations need to be updated
void updatePatrons(Library *library)
{
    // First check if a new patron has arrived. If so, set up the patron in the queue
    if ((previousPatronQueue[0].patronPid == 0) && (library->patronQueue[0].patronPid != 0))
    {
        patrons[numPatrons].patronPid = library->patronQueue[0].patronPid;
        patrons[numPatrons].rentalNumber = NO_RENTAL_YET;
        patrons[numPatrons].queueIndex = 0;
        patrons[numPatrons].currX = 0 - PATRON_WIDTH / 2;
        patrons[numPatrons].currY = ENV_HEIGHT;
        patrons[numPatrons].speed = 1;
        patrons[numPatrons].color = WAIT_TO_RENT_COLOR;
        patrons[numPatrons].rental = library->patronQueue[0].rental;
        numPatrons++;

        // Set the destinationX to be as far up the line as possible
        for (int i = 1; i < MAX_PATRONS - 1; i++)
        {
            if (library->patronQueue[i].patronPid == 0)
            {
                patrons[numPatrons].destX = i * PATRON_WIDTH + i * PATRON_GAP;
            }
        }
    }

    // For each patron, check if they moved forward in the queue and update destination
    for (int i = 0; i < numPatrons; i++)
    {
        // Detect if the patron has moved forward
        if (library->patronQueue[patrons[i].queueIndex].patronPid != patrons[i].patronPid)
        {
            // Find where they should be
            char foundAt = -1;
            for (int j = patrons[i].queueIndex + 1; j < MAX_PATRONS; j++)
            {
                if (library->patronQueue[j].patronPid == patrons[i].patronPid)
                {
                    foundAt = j;
                    break;
                }
            }

            // Update the destination for the patron
            if (foundAt > 0)
            {
                patrons[i].destX = foundAt * PATRON_WIDTH + foundAt * PATRON_GAP;
                if (patrons[i].speed == 0)
                    patrons[i].speed = 1; // start moving if stopped
                patrons[i].queueIndex = foundAt;
                patrons[i].rentalNumber = library->patronQueue[foundAt].rental.rentalNumber;
                patrons[i].rental = library->patronQueue[foundAt].rental;
            }
            else
            {
                // Patron has reached the end, send them off screen
                patrons[i].queueIndex = MAX_PATRONS;
            }
        }
    }

    // Check if a patron has gone off-screen, and if so, remove them from the queue
    if ((numPatrons > 0) && (patrons[0].queueIndex == MAX_PATRONS) && (patrons[0].currX > 10 * PATRON_WIDTH + 10 * PATRON_GAP - 1))
    {
        // Remove the patron and their books from the display
        for (int i = 0; i < numPatrons - 1; i++)
        {
            patrons[i] = patrons[i + 1];
        }
        numPatrons--;  // Decrease the number of patrons in the queue
    }

    // Keep previous queue data for next time
    for (int i = 0; i < MAX_PATRONS; i++)
        previousPatronQueue[i] = library->patronQueue[i];
}

// Redraw the library queue repeatedly
void *runDisplay(void *r)
{
    Library *library = (Library *)r;

    initializeWindow();

    // Get a copy of the initial patron queue
    for (int i = 0; i < MAX_PATRONS; i++)
        previousPatronQueue[i] = library->patronQueue[i];

    // Now keep redrawing until someone kills the thread
    while (1)
    {
        // Draw the background
        drawBackground();

        // Update the patron locations
        updatePatrons(library);

        // Draw the patrons
        for (int i = 0; i < numPatrons; i++)
        {
            // Set the correct patron color
            if (patrons[i].queueIndex == MAX_PATRONS - 1)
            {
                if (patrons[i].rentalNumber == NO_RENTAL_YET)
                {
                    if (patrons[i].speed == 0)
                        patrons[i].color = RENTING_COLOR;
                }
                else
                    patrons[i].color = WAIT_TO_PICKUP_COLOR;
            }
            else
            {
                if (patrons[i].queueIndex >= MAX_PATRONS)
                {
                    patrons[i].color = WAIT_TO_PICKUP_COLOR;
                    if (patrons[i].queueIndex == MAX_PATRONS - 1)
                    {
                        if (patrons[i].speed == 0)
                            patrons[i].color = PICKING_UP_COLOR;
                    }
                    else if (patrons[i].queueIndex == MAX_PATRONS)
                    {
                        patrons[i].color = WAIT_TO_RENT_COLOR;
                    }
                }
            }

            // Draw the patron now, along with their rental info
            drawPatron(patrons[i].queueIndex * PATRON_WIDTH + patrons[i].queueIndex * PATRON_GAP, patrons[i].currY, patrons[i].color, patrons[i].rentalNumber, patrons[i].rental);

            // Move the patron forward if it has not yet reached its destination, otherwise stop it
            if (patrons[i].currX < patrons[i].destX)
            {
                patrons[i].currX += patrons[i].speed;
                if (patrons[i].currX > patrons[i].destX)
                    patrons[i].currX = patrons[i].destX;
            }
            else
            {
                patrons[i].speed = 0;
            }
        }

        // Display the latest rental info
        drawRental(library);

        XFlush(display);
        usleep(2000);
    }

    closeWindow();
    pthread_exit(NULL);
}
