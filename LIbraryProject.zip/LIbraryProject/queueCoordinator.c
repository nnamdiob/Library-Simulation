#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <semaphore.h>

#include "library.h"

// Go into an infinite loop to update the patronQueue
void *runQueueCoordination(void *r)
{
  Library *library = (Library *)r;

  while (1)
  {
    sem_wait(&library->QueueSemaphore);

    // If a patron is waiting to pick up a rental that is ready
    if (library->patronQueue[PICKUP_WINDOW].patronPid != 0 &&
        library->patronQueue[PICKUP_WINDOW].rental.secondsUntilReady <= 0)
    {
      kill(library->patronQueue[PICKUP_WINDOW].patronPid, SIGUSR2);

      library->patronQueue[PICKUP_WINDOW].patronPid = 0;
      library->patronQueue[PICKUP_WINDOW].startedRental = 0;
      library->patronQueue[PICKUP_WINDOW].rental.rentalNumber = NO_RENTAL_YET;
    }

    // Move up patrons to pick-up window
    if (library->patronQueue[RENTAL_WINDOW].rental.rentalNumber)
      for (int i = PICKUP_WINDOW; i > RENTAL_WINDOW; i--)
        if (library->patronQueue[i].rental.rentalNumber == NO_RENTAL_YET &&
            library->patronQueue[i - 1].rental.rentalNumber != NO_RENTAL_YET)
        {
          library->patronQueue[i] = library->patronQueue[i - 1];

          library->patronQueue[i - 1].patronPid = 0;
          library->patronQueue[i - 1].startedRental = 0;
          library->patronQueue[i - 1].rental.rentalNumber = NO_RENTAL_YET;
        }

    // Move up patrons to rental window
    for (int i = RENTAL_WINDOW; i > 0; i--)
      if (library->patronQueue[i].patronPid == 0 &&
          library->patronQueue[i - 1].patronPid != 0)
      {
        // Move the patron forward one spot
        library->patronQueue[i] = library->patronQueue[i - 1];

        // Clear the previous spot
        library->patronQueue[i - 1].patronPid = 0;
        library->patronQueue[i - 1].startedRental = 0;
        library->patronQueue[i - 1].rental.rentalNumber = NO_RENTAL_YET;
      }

    // If a patron is ready to rent
    if (library->patronQueue[RENTAL_WINDOW].patronPid &&
        !library->patronQueue[RENTAL_WINDOW].startedRental)
    {
      kill(library->patronQueue[RENTAL_WINDOW].patronPid, SIGUSR1);
      library->patronQueue[RENTAL_WINDOW].startedRental = 1;
    }

    sem_post(&library->QueueSemaphore);
    sleep(1); // Moved sleep to after computation.
  }
}
