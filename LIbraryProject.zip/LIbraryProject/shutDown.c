#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#include "library.h" 

void main()
{
  int clientSocket;                 // client socket id
  struct sockaddr_in clientAddress; // client address
  int status;

  // Create socket
  clientSocket = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
  if (clientSocket < 0)
  {
    printf("*** LIBRARY SHUTDOWN ERROR: Could not open socket\n"); // Updated message
    exit(-1);
  }

  // Set up client address
  memset(&clientAddress, 0, sizeof(clientAddress));
  clientAddress.sin_family = AF_INET;
  clientAddress.sin_addr.s_addr = inet_addr(SERVER_IP);
  clientAddress.sin_port = htons(SERVER_PORT);

  // Connect to LibraryServer
  if (connect(clientSocket, (struct sockaddr *)&clientAddress, sizeof(clientAddress)) < 0)
  {
    printf("*** LIBRARY SHUTDOWN ERROR: Could not connect to server\n"); // Updated message
    close(clientSocket);
    exit(-1);
  }

  // Send SHUT_DOWN command to the server
  unsigned char command = SHUT_DOWN;
  write(clientSocket, &command, sizeof(command));

  close(clientSocket);
  printf("Sent SHUT_DOWN command to LibraryServer.\n"); // Updated message
}
