#include <semaphore.h>

// Buffer constants
#define BUFFER_PADDING 6
#define COMMAND_BIT 0
#define BOOK_COUNT_BIT 5

// #define DEBUG	1

#define MAX_BOOKS_PER_RENTAL 10 // Maximum number of books a patron can rent at once
#define MAX_PATRONS_WAITING_TO_RENT 5 // Maximum number of patrons allowed to wait for rental
#define MAX_PATRONS_WAITING_FOR_BOOKS 5 // Maximum number of patrons waiting to collect books
#define MAX_PATRONS 10 // Maximum number of patrons being dealt with at any time
#define MAX_RENTALS 6 // Maximum number of rentals being processed at any time
#define NUM_BOOK_ITEMS 11 // Number of book items available for rent
#define MAX_BOOK_TITLE_SIZE 15 // Maximum number of characters in a book title

// Window related Constants
#define START_OF_LINE 0
#define RENTAL_WINDOW 4
#define PICKUP_WINDOW 9

// Commands that the Library Server may get
#define ARRIVED 1 // Inform the library that a patron has arrived
#define PLACE_RENTAL 2 // Place a book rental request at the desk
#define SHUT_DOWN 3 // Shut down the library system

// Responses that the Library Server may send back
#define ACCEPTED 4 // Patron able to get in line
#define DENIED 5 // Patron not able to get in line

// Rental-related constants
#define NO_RENTAL_YET 255 // Indicates that no rental has been made yet
#define PACK_TIME 2 // Time it takes (in seconds) to prepare the books for pickup

// Settings for Library Server setup
#define SERVER_IP "127.0.0.1"  // IP address of LibraryServer
#define SERVER_PORT 6000  // PORT of the LibraryServer

// Represents a book that can be rented
typedef struct bi {
    const char *title; // Title of the book
    float rentalFee; // Fee for renting the book
} BookItem;

// Represents a book rental request that a patron makes
typedef struct ren {
    unsigned char rentalNumber; // Unique rental number for each patron
    BookItem books[MAX_BOOKS_PER_RENTAL]; // The books rented
    unsigned char numBooks; // Number of books rented
    short secondsUntilReady; // Time until books are ready for pickup
} Rental;

// Represents a patron in line
typedef struct pat {
    unsigned int patronPid;  // Process ID of this patron
    Rental rental;           // Rental that patron made, NULL if not made yet
    char startedRental;      // Set to true if we told the patron to start renting
} Patron;

// Represents the shared data in the library
typedef struct lib {
    Patron patronQueue[MAX_PATRONS]; // Patrons in line
    unsigned int nextRentalNumber;   // Global patron count
    sem_t QueueSemaphore;            // Allows us to lock up queue
} Library;

// External Global Variables
extern const char *BookTitles[NUM_BOOK_ITEMS]; // Titles of available books
extern const float BookRentalFees[NUM_BOOK_ITEMS]; // Rental fees for the books
extern const float BookPrepTime[NUM_BOOK_ITEMS]; // Time to prepare each book
extern const float BookFillTime[NUM_BOOK_ITEMS]; // Time to gather each book
