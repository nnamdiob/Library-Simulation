#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <semaphore.h>

#include "library.h" 

// Go into an infinite loop to update the time that rentals need to be processed by decrementing the
// secondsUntilReady values for each rental that was placed
void *runTimer(void *r)
{
  Library *library = (Library *)r; 

  while (1)
  {
    usleep(30000);                          // wait 1/30th of a second ... roughly
    sem_wait(&library->QueueSemaphore);      // Lock access to modify rentals safely

    for (int i = PICKUP_WINDOW; i > RENTAL_WINDOW; i--)  // Changed from ORDER_WINDOW to RENTAL_WINDOW
      if (library->patronQueue[i].patronPid != 0 &&      // Changed from customerPid to patronPid
          library->patronQueue[i].startedRental &&       // Changed from startedOrder to startedRental
          library->patronQueue[i].rental.secondsUntilReady > 0)
        library->patronQueue[i].rental.secondsUntilReady--;  // Decrement the time until rental is ready

    sem_post(&library->QueueSemaphore);      // Unlock after updates
  }
}
