
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <time.h>
#include <sys/wait.h>

#include "library.h" 
int main()
{
  srand(time(NULL));

  for (int i = 0; i < 10; i++) // Reduced the number of patrons to 10
  {
    pid_t pid = fork();

    // Child process will create 1-10 random book rentals
    if (pid == 0)
    {
      int numBooks = rand() % 10 + 1;  // Random number of books between 1 and 10
      char *args[numBooks + 2];        // +2 for the program name and NULL terminator

      args[0] = "./patron";            // Updated from "./customer" to "./patron"

      // Allocate memory for books, then populate args with numBooks random books
      for (int j = 1; j <= numBooks; j++)
      {
        args[j] = malloc(5);
        snprintf(args[j], 5, "%d", rand() % NUM_BOOK_ITEMS ); // Updated from NUM_MENU_ITEMS to NUM_BOOK_ITEMS
      }
      args[numBooks + 1] = NULL;

      execvp(args[0], args); // Execute patron process

      // Free allocated memory
      for (int k = 1; k <= numBooks; k++)
        free(args[k]);

      exit(0); // Exit child process
    }
    // Parent process waits before next iteration
    else if (pid > 0)
    {
      // Increased the wait time to up to 10 seconds to allow better spacing
      usleep((rand() % 20 + 10) * 500000); // Wait between 5 to 15 seconds
    }
    // Handle failure
    else
    {
      printf("Failed to fork\n");
      exit(1);
    }
  }

  // Wait for all child processes to finish
  while (wait(NULL) > 0)
    ;

  return 0;
}
