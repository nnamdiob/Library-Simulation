

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <semaphore.h>
#include <sys/time.h>
#include <time.h>

#include "library.h"

// Get the current time in microseconds
long getTimeInMicroseconds()
{
    struct timeval currentTime;
    gettimeofday(&currentTime, NULL);
    return currentTime.tv_sec * (int)1e6 + currentTime.tv_usec;
}

// Initialize the librarian by creating the server socket, setting up the server address,
// binding the server socket and setting up the server to listen for patron clients.
void initializeServer(int *serverSocket, struct sockaddr_in *serverAddress)
{
    int status;

    // Create the server socket
    *serverSocket = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
    if (*serverSocket < 0)
    {
        printf("*** LIBRARY SERVER ERROR: Could not open socket.\n");
        exit(-1);
    }

    // Setup the server address
    memset(serverAddress, 0, sizeof(*serverAddress)); // zeros the struct
    (*serverAddress).sin_family = AF_INET;
    (*serverAddress).sin_addr.s_addr = htonl(INADDR_ANY);
    (*serverAddress).sin_port = htons((unsigned short)SERVER_PORT);

    // Bind the server socket
    int one = 1;
    setsockopt(*serverSocket, SOL_SOCKET, SO_REUSEADDR, &one, sizeof(one));
    status = bind(*serverSocket, (struct sockaddr *)serverAddress, sizeof(*serverAddress));
    if (status < 0)
    {
        printf("*** LIBRARY SERVER ERROR: Could not bind socket.\n");
        exit(-1);
    }

    // Set up the queue to handle up to 10 buffered patrons
    status = listen(*serverSocket, 10);
    if (status < 0)
    {
        printf("*** LIBRARY SERVER ERROR: Could not listen on socket.\n");
        exit(-1);
    }
}


void startAcceptingPatrons(Library *library)
{
    unsigned char inBuffer[MAX_BOOKS_PER_RENTAL + BUFFER_PADDING];
    unsigned char response[10];

    // Initialize buffers before use
    memset(inBuffer, 0, sizeof(inBuffer));
    memset(response, 0, sizeof(response));

    int addrSize, bytesRcv;
    int serverSocket, clientSocket;
    struct sockaddr_in serverAddress, clientAddr;

    // Initialize the server
    initializeServer(&serverSocket, &serverAddress);
    addrSize = sizeof(clientAddr);
    printf("\nLIBRARIAN: online\n");

    char online = 1;

    // Wait for patrons now
    while (online)
    {
        clientSocket = accept(serverSocket, (struct sockaddr *)&clientAddr, (socklen_t *)&addrSize);
        if (clientSocket >= 0)
        {
            bytesRcv = recv(clientSocket, inBuffer, sizeof(inBuffer), 0);

            // Error in receiving bytes
            if (bytesRcv < 0)
            {
                close(clientSocket); // Error receiving data, close socket and continue
                continue;
            }
			

            // Handle patron arrived
            if (inBuffer[COMMAND_BIT] == ARRIVED)
            {
                // Get PID
                unsigned int patronPid = 0;
                memcpy(&patronPid, inBuffer + 1, sizeof(patronPid));

                sem_wait(&library->QueueSemaphore);

                // If there is space for the new patron
                if (library->patronQueue[0].patronPid == 0)
                {
                    library->patronQueue[0].patronPid = patronPid;
                    library->patronQueue[0].startedRental = 0;
                    library->patronQueue[0].rental.rentalNumber = NO_RENTAL_YET;
                    response[0] = ACCEPTED;
                }
                else
                {
                    response[0] = DENIED;
                }

                sem_post(&library->QueueSemaphore);
                send(clientSocket, &response, sizeof(response), 0);
            }

           
			// Handle patron rental
			if (inBuffer[COMMAND_BIT] == PLACE_RENTAL)
			{
				// Get PID and numBooks
				unsigned int patronPid = 0;
				memcpy(&patronPid, inBuffer + 1, sizeof(patronPid));
				int bookCount = inBuffer[BOOK_COUNT_BIT];

				sem_wait(&library->QueueSemaphore);

				// Find this particular patron
				for (int i = 0; i < MAX_PATRONS; i++)
				{
					if (library->patronQueue[i].patronPid == patronPid)
					{
						// Update their book count
						library->patronQueue[i].rental.numBooks = bookCount;

						// Calculate the prep time and update their books
						int totalPrepTime = 0;
						for (int j = 0; j < bookCount; j++)
						{
							unsigned char bookIndex = inBuffer[j + 6];

							// Validate bookIndex is within bounds
							if (bookIndex < NUM_BOOK_ITEMS)
							{
								BookItem rentalBook = {BookTitles[bookIndex], BookRentalFees[bookIndex]};
								library->patronQueue[i].rental.books[j] = rentalBook;

								totalPrepTime += BookPrepTime[bookIndex] + BookFillTime[bookIndex] + PACK_TIME;
							}
							else
							{
								// Log the invalid book index and mark the rental as invalid
								printf("Invalid book index: %d. Aborting rental.\n", bookIndex);
								library->patronQueue[i].rental.numBooks = 0; // Marking as invalid
								break;
							}
						}

						// If the rental is valid, update the prep time
						if (library->patronQueue[i].rental.numBooks > 0)
						{
							library->patronQueue[i].rental.secondsUntilReady = totalPrepTime;
							library->patronQueue[i].rental.rentalNumber = ++(library->nextRentalNumber);
						}
						break;
					}
				}

				sem_post(&library->QueueSemaphore);
			}


            // Handle shutdown
            if (inBuffer[COMMAND_BIT] == SHUT_DOWN)
            {
                // Shutdown connected patrons (in case they are running in the background)
                for (int i = 0; i < MAX_PATRONS; i++)
                {
                    if (library->patronQueue[i].patronPid != 0)
                    {
                        kill(library->patronQueue[i].patronPid, SIGINT);
                    }
                }
                online = 0;
            }

            close(clientSocket);
        }
    }

    close(serverSocket);
    printf("LIBRARIAN: Shutting down...\n");
}

