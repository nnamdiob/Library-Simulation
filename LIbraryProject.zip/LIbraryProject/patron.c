#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <signal.h>
#include <time.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#include "library.h" // Changed from "restaurant.h"

#define BUFFER_LIMIT 100

// Global args
int gargc;
char **gargv;

// Signal Handler flags
volatile sig_atomic_t rentalSignalReceived = 0; // Renamed from orderSignalReceived
volatile sig_atomic_t rentalReady = 0; // Renamed from orderReady

// A LibraryServer connection ... when made
int clientSocket;                 // client socket id
struct sockaddr_in clientAddress; // client address

// Set up a client socket and connect to the LibraryServer. Return -1 if there was an error.
int connectToLibraryServer(int *sock, struct sockaddr_in *address) // Renamed from connectToRestaurantServer
{
  int status;

  // Create socket
  *sock = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
  if (*sock < 0)
  {
    printf("*** PATRON ERROR: Could open socket to Library Server\n");
    return (-1);
  }
  // Setup address
  memset(address, 0, sizeof(struct sockaddr_in));
  address->sin_family = AF_INET;
  address->sin_addr.s_addr = inet_addr(SERVER_IP);
  address->sin_port = htons((unsigned short)SERVER_PORT);

  // Connect to server
  status = connect(*sock, (struct sockaddr *)address, sizeof(struct sockaddr_in));
  if (status < 0)
  {
    close(*sock);
    printf("*** PATRON ERROR: Could not connect to Library Server\n");
    return (-1);
  }
  return 0;
}


void handleRentalSignal(int sig)
{
    // Update signal flag
    rentalSignalReceived = 1;

    int numBooks = gargc - 1;
    unsigned char buffer[MAX_BOOKS_PER_RENTAL + BUFFER_PADDING];
    int rentalSocket;
    struct sockaddr_in rentalAddress;

    // Simulate rental request processing time
    usleep(1000000 + 200000 * numBooks);

    // Attempt to connect to library 3 times before aborting
    int connectionAttempts = 0;
    while (connectToLibraryServer(&rentalSocket, &rentalAddress)) 
    {
        connectionAttempts++;
        sleep(2);
        if (connectionAttempts >= 3)
            exit(-1);
    }

    // Debug: Print number of books being rented
    printf("Number of books being rented: %d\n", numBooks);

    // Send command, PID, numBooks, and book indexes to library
    unsigned int pid = getpid();
    buffer[COMMAND_BIT] = PLACE_RENTAL;
    memcpy(buffer + 1, &pid, sizeof(pid));
    buffer[BOOK_COUNT_BIT] = numBooks;

    // Ensure book IDs are being properly sent
    for (int i = 6, j = 0; (i < sizeof(buffer)) && (j < numBooks); i++, j++)
    {
        int bookIndex = atoi(gargv[j + 1]);
        if (bookIndex >= 1 && bookIndex <= NUM_BOOK_ITEMS)
        {
            buffer[i] = bookIndex - 1; // Send zero-indexed book ID

            // Debug: Print the book index being sent
            printf("Sending book index: %d\n", bookIndex - 1);
        }
        else
        {
            printf("Invalid book index: %d\n", bookIndex);
            exit(-1);
        }
    }

    // Debug: Print the entire buffer before sending
    printf("Buffer contents being sent to server: ");
    for (int i = 0; i < sizeof(buffer); i++) {
        printf("%d ", buffer[i]);
    }
    printf("\n");

    write(rentalSocket, buffer, sizeof(buffer)); // Send the buffer to the library server
    close(rentalSocket);
}


// Update rental ready flag to allow exit
void handleRentalReady(int sig) // Renamed from handleOrderReady
{
  rentalReady = 1;
}

// Start up a Patron process. There should be a sequence of integers as command line arguments.
// Each integer must be a number from 1 to the number of book items available.
void main(int argc, char *argv[])
{
  struct sockaddr_in libraryServerAddress;                // client address for library server
  int libraryServerSocket;                                // client socket id for library server
  int status;                                             // status from a sent message
  int bytesRcv;                                           // number of bytes received
  unsigned char buffer[MAX_BOOKS_PER_RENTAL + BUFFER_PADDING]; // buffer used for sending and receiving data

  // Bind signal handlers
  signal(SIGUSR1, handleRentalSignal); // Renamed from handleOrderSignal
  signal(SIGUSR2, handleRentalReady);  // Renamed from handleOrderReady

  for (int i = 1; i < argc; i++)
    if (atoi(argv[i]) >= NUM_BOOK_ITEMS) // Renamed from NUM_MENU_ITEMS
    {
      printf("Invalid book items, aborting.\n");
      return;
    }

  // Global args for signal handlers
  gargc = argc;
  gargv = argv;

  // Wait to be accepted into the line
  while (buffer[COMMAND_BIT] != ACCEPTED)
  {
    // Attempt to connect to library 3 times before aborting
    int connectionAttempts = 0;
    while (connectToLibraryServer(&libraryServerSocket, &libraryServerAddress)) // Renamed from connectToRestaurantServer
    {
      connectionAttempts++;
      sleep(2);
      if (connectionAttempts >= 3)
        exit(-1);
    }

    // Send command and PID
    unsigned int pid = getpid();
    buffer[COMMAND_BIT] = ARRIVED;
    memcpy(buffer + 1, &pid, sizeof(pid));

    write(libraryServerSocket, buffer, sizeof(buffer));
    bytesRcv = read(libraryServerSocket, buffer, 1);
    close(libraryServerSocket);

    if (buffer[COMMAND_BIT] == DENIED)
    {
      printf("Denied. Trying again in 2 seconds...\n");
      sleep(2);
    }
  }
  printf("Accepted into the rental line.\n"); // Renamed from drive-thru line

  while (!rentalSignalReceived)
    sleep(2); // Wait for SIGUSR1 signal
  printf("Rental signal received\n");

  while (!rentalReady)
    sleep(2); // Wait for SIGUSR2 signal
  printf("Rental ready received\n");
}
